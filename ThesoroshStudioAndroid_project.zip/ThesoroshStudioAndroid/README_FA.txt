Thesorosh Studio - Android project

برای ساخت APK:
1) Android Studio را روی کامپیوتر نصب کن.
2) این پوشه را با گزینه Open در Android Studio باز کن.
3) صبر کن Gradle Sync تمام شود.
4) از منوی Build > Build Bundle(s) / APK(s) > Build APK(s) را بزن.
5) فایل APK در مسیر app/build/outputs/apk/debug/app-debug.apk ساخته می‌شود.
6) فایل را به گوشی منتقل و نصب کن. ممکن است لازم باشد اجازه Install unknown apps را برای برنامه‌ای که فایل را باز می‌کند فعال کنی.

این اپ آفلاین است و رابط سازنده تصویر را از فایل داخلی اجرا می‌کند.
گزارش‌ها صرفاً ماکت نمایشی هستند و وضعیت واقعی حساب‌های اینستاگرام را بررسی نمی‌کنند.
